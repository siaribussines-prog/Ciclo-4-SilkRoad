package silkroad;
import java.util.*;

public class AutonomousStore extends Store {

    public AutonomousStore(int location, int tenges, int x, int y) {
        super(location, tenges, x, y);

        // reasignar la ubicación a una aleatoria dentro del camino
        Random r = new Random();
        int newLoc = r.nextInt(Math.max(1, 100));

        setLocation(newLoc);  
    }
}
