package silkroad;

/**
 * Los únicos robots que pueden tomar su dinero son los que
 * tienen más dinero que la tienda.
 * @author Sara
 */
public class FighterStore extends Store {

    public FighterStore(int location, int tenges, int x, int y) {
        super(location, tenges, x, y);
    }

    @Override
    public int collect(Robot r) {
        if (r == null) return 0;

        // Solo entrega si el robot tiene más dinero que la tienda
        if (r.getMoney() > getTenges()) {
            // respeta también la regla del robot (tender toma mitad, etc.)
            return super.collect(r);
        }
        return 0;
    }
}
