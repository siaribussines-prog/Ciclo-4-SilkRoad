package silkroad;

/**
 * Tienda que ya tenemos
 * 
 * @author (Sara Gonzalez)
 */
public class NormalStore extends Store {
    public NormalStore(int location, int tenges, int x, int y) {
        super(location, tenges, x, y);
    }
}
