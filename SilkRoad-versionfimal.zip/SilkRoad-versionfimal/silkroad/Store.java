package silkroad;
import shapes.*;
/**
 * La clase que tiene los metodos de SkillRoad en Store
 * Sara G 
 */
public class Store {
    private int location;
    private int tenges;
    private int initialTenges;
    private Rectangle box;
    private Triangle rooft;
    //ciclo 2//
    private int emptiedCount;

    public Store(int location, int tenges, int x, int y) {
        this.location = location;
        this.tenges = tenges;
        this.initialTenges = tenges;
    
        box = new Rectangle();
        box.changeSize(30, 100);
        box.setXPosition(x + 75);
        box.setYPosition(y + 50);
    
        rooft = new Triangle();
        rooft.changeSize(50, 100);
        rooft.setXPosition(x + 125);
        rooft.setYPosition(y);
    }


    public void changeColor(String color){
        box.changeColor(color);
        rooft.changeColor(color);
    }

    public void graphicMove(int row, int col) {
        int baseX = 250 * col;
        int baseY = 250 * row;
    
        box.setXPosition(75 + baseX);
        box.setYPosition(50 + baseY);
    
        rooft.setXPosition(125 + baseX);
        rooft.setYPosition(baseY);
    }


    public void makeVisible() {
        box.makeVisible();
        rooft.makeVisible();
    }

    public void makeInvisible() {
        box.makeInvisible();
        rooft.makeInvisible();
    }

    public int getLocation() { return location; }
    public int getTenges()   { return tenges;   }

    public void reset() {
        this.tenges = initialTenges;
    }

    /** Comportamiento por defecto: vacía la tienda y retorna todo el dinero. */
    public int collect() {
        int temp = tenges;
        tenges = 0;
        if (temp > 0) {
            emptiedCount++; // cada vez que se vacía, incrementa
        }
        return temp;
    }

    /** Punto de extensión (Ciclo 4): por defecto delega al collect() normal. */
    public int collect(Robot r) {
        return collect();
    }

    //ciclo 2//
    public int getEmptiedCount() { 
        return emptiedCount; 
    }
    
    public void setLocation(int newLocation) {
    this.location = newLocation;
    }

}



















