package test;
import silkroad.*;
import static org.junit.Assert.*;
import org.junit.Test;

public class SilkRoadC4Test {

    @Test
    public void neverBackRobotNoPermiteMovimientoNegativo() throws Exception {
        SilkRoad sr = new SilkRoad(30);
        sr.placeStore(10, 40);
        sr.placeRobot("neverback", 12);

        sr.moveRobot(12, -3);              // no permitido
        assertFalse(sr.ok());
    }

    @Test
    public void tenderRobotCobraLaMitad() throws Exception {
        SilkRoad sr = new SilkRoad(30);
        sr.placeStore(10, 80);             // tienda con 80
        sr.placeRobot("tender", 5);

        sr.moveRobot(5, +5);               // costo=5; cobra 40 => ganancia 35
        assertTrue(sr.ok());
        assertEquals(35, sr.profit());
    }

    @Test
    public void fighterStoreSoloDejaFighterRobot() throws Exception {
        SilkRoad sr = new SilkRoad(30);
        sr.placeStore("fighter", 8, 60);
        sr.placeRobot("normal", 0);
        sr.placeRobot("fighter", 1);

        sr.moveRobot(0, 8);                 // normal no cobra
        int profitTrasNormal = sr.profit();

        sr.moveRobot(1, 7);                 // fighter cobra 60-7 = 53
        assertEquals(profitTrasNormal + 53, sr.profit());
    }

    @Test
    public void smartRobotEvitaMovimientoNoRentable() throws Exception {
        SilkRoad sr = new SilkRoad(30);
        sr.placeStore(20, 3);               // poca plata
        sr.placeRobot("smart", 10);

        sr.moveRobot(10, +10);              // 3 < 10 => no rentable
        assertFalse(sr.ok());
    }

    @Test
    public void autonomousStoreQuedaDentroDeLaRuta() throws Exception {
        int len = 50;
        SilkRoad sr = new SilkRoad(len);
        sr.placeStore("autonomous", 0, 50); // se auto-ubica
        int[][] st = sr.stores();
        // verifica que hay por lo menos una tienda y que su loc está en rango
        assertTrue(st.length >= 1);
        assertTrue(st[0][0] >= 0 && st[0][0] < len);
    }
}

