package silkroad;
import shapes.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Crea un cell que cambia de color
 *
 * 
 * Sara G 
 * @version (1.0)
 */

public class Cell {
    
    private String color;   
    private boolean hole;      
    private boolean hasMarbel;
    private Rectangle box;
    private Rectangle border;
    
    public static final int SIZE = 250;
    public static final int MARGIN = Math.round(SIZE*0.016f);
    
    public Cell(String color, boolean hole, int x, int y) {
        this.color = color;
        this.hole = hole;
        
        border = new Rectangle();
        border.changeSize(SIZE, SIZE);
        border.changeColor("black");
        border.moveHorizontal(x);
        border.moveVertical(y);
        
        box = new Rectangle();
        box.changeSize(SIZE - MARGIN, SIZE - MARGIN);
        box.changeColor(color);
        box.moveHorizontal(x+MARGIN/2);
        box.moveVertical(y+MARGIN/2);
    }
    

    public void makeVisible() {
        border.makeVisible();
        box.makeVisible();
    }

    public void makeInvisible() {
        border.makeInvisible();
        box.makeInvisible();
    }

    
    public String getColor() {
        return color;
    }
    
    public int getSize() {
        return SIZE;
    }
    
    public void setColor(String newColor) {
    this.color = newColor;
    box.changeColor(newColor); 
    box.makeVisible();
    }
    
    
}
