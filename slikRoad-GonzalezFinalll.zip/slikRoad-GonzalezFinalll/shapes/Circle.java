package shapes;

import silkroad.Canvas;
import java.awt.*;
import java.awt.geom.*;
import javax.swing.*;

/**
 * A circle that can be manipulated and that draws itself on a canvas.
 * 
 * @author  Michael Kolling and David J. Barnes
 * @version 1.1  (28 Oct 2025)
 */

public class Circle {

    public static final double PI = 3.1416;

    private int diameter;
    private int xPosition;
    private int yPosition;
    private String color;
    private boolean isVisible;

    /**
     * Create a new circle at default position with default color.
     */
    public Circle() {
        diameter = 100;
        xPosition = 0;
        yPosition = 0;
        color = "blue";
        isVisible = false;
    }

    // --- NUEVOS MÉTODOS PARA POSICIÓN DIRECTA ---
    public void setXPosition(int x) {
        erase();
        xPosition = x;
        draw();
    }

    public void setYPosition(int y) {
        erase();
        yPosition = y;
        draw();
    }

    // --- VISIBILIDAD ---
    public void makeVisible() {
        isVisible = true;
        draw();
    }

    public void makeInvisible() {
        erase();
        isVisible = false;
    }

    // --- DIBUJAR Y BORRAR ---
    private void draw() {
        if (isVisible) {
            Canvas canvas = Canvas.getCanvas();
            canvas.draw(this, color,
                new Ellipse2D.Double(xPosition, yPosition, diameter, diameter));
            canvas.wait(10);
        }
    }

    private void erase() {
        if (isVisible) {
            Canvas canvas = Canvas.getCanvas();
            canvas.erase(this);
        }
    }

    // --- MOVIMIENTO SIMPLE ---
    public void moveRight() {
        moveHorizontal(20);
    }

    public void moveLeft() {
        moveHorizontal(-20);
    }

    public void moveUp() {
        moveVertical(-20);
    }

    public void moveDown() {
        moveVertical(20);
    }

    // --- MOVIMIENTO PRECISO ---
    public void moveHorizontal(int distance) {
        erase();
        xPosition += distance; // corregido (antes =)
        draw();
    }

    public void moveVertical(int distance) {
        erase();
        yPosition += distance; // corregido (antes =)
        draw();
    }

    // --- MOVIMIENTO SUAVE ---
    public void slowMoveHorizontal(int distance) {
        int delta = (distance < 0) ? -1 : 1;
        int steps = Math.abs(distance);

        for (int i = 0; i < steps; i++) {
            xPosition += delta;
            draw();
        }
    }

    public void slowMoveVertical(int distance) {
        int delta = (distance < 0) ? -1 : 1;
        int steps = Math.abs(distance);

        for (int i = 0; i < steps; i++) {
            yPosition += delta;
            draw();
        }
    }

    // --- CAMBIO DE TAMAÑO Y COLOR ---
    public void changeSize(int newDiameter) {
        if (newDiameter < 0) return;
        erase();
        diameter = newDiameter;
        draw();
    }

    public void changeColor(String newColor) {
        color = newColor;
        draw();
    }

    // --- CÁLCULO DE ÁREA ---
    public double area() {
        return Math.pow(diameter / 2.0, 2) * PI;
    }

    // --- AGRANDAR ---
    public void bigger(int percentage) {
        if (percentage < 0 || percentage > 100) {
            System.out.println("Porcentaje inválido");
            return;
        }

        double factor = Math.sqrt(1 + percentage / 100.0);
        int newDiameter = (int) (diameter * factor);
        System.out.println("El nuevo diámetro es: " + newDiameter);
        changeSize(newDiameter);
        System.out.println("Área: " + area());
    }

    // --- REDUCIR ---
    public void shrink(int times, double minArea) {
        if (times <= 0 || minArea <= 0) return;
        if (!isVisible) return;

        for (int i = 0; i < times; i++) {
            if (area() <= minArea) break;
            int newDiameter = (int) Math.round(diameter * 0.9);
            changeSize(newDiameter);
        }
    }

    // --- CAMBIO DE COLOR POR DIÁLOGO ---
    public void CambioColor() {
        String nuevoColor = JOptionPane.showInputDialog("Dime el nuevo color del círculo:");
        if (nuevoColor != null && !nuevoColor.isEmpty()) {
            changeColor(nuevoColor);
        }
    }

    // --- CAMBIAR TAMAÑO A PARTIR DE UN ÁREA ---
    public void changeSizeArea(int newArea) {
        if (newArea <= 0) return;
        int radio = (int) Math.round(Math.sqrt(newArea / PI));
        int diametro = radio * 2;
        changeSize(diametro);
    }
}
