package shapes;

import silkroad.Canvas;
import java.awt.*;

/**
 * A rectangle that can be manipulated and that draws itself on a canvas.
 * 
 * @author  Michael Kolling and David J. Barnes (Modified)
 * @version 1.1  (28 Oct 2025)
 */

public class Rectangle {

    public static int EDGES = 4;

    private int height;
    private int width;
    private int xPosition;
    private int yPosition;
    private String color;
    private boolean isVisible;

    /**
     * Create a new rectangle at default position with default color.
     */
    public Rectangle() {
        height = 50;
        width = 100;
        xPosition = 0;
        yPosition = 0;
        color = "red";
        isVisible = false;
    }
    
        public Rectangle(int x, int y) {
        height = 50;
        width = 100;
        xPosition = x;
        yPosition = y;
        color = "red";
        isVisible = false;
    }


    // --- NUEVOS MÉTODOS PARA POSICIÓN DIRECTA ---
    public void setXPosition(int x) {
        erase();
        xPosition = x;
        draw();
    }

    public void setYPosition(int y) {
        erase();
        yPosition = y;
        draw();
    }

    // --- VISIBILIDAD ---
    public void makeVisible() {
        isVisible = true;
        draw();
    }

    public void makeInvisible() {
        erase();
        isVisible = false;
    }

    // --- MOVIMIENTO SIMPLE ---
    public void moveRight() {
        moveHorizontal(20);
    }

    public void moveLeft() {
        moveHorizontal(-20);
    }

    public void moveUp() {
        moveVertical(-20);
    }

    public void moveDown() {
        moveVertical(20);
    }

    // --- MOVIMIENTO PRECISO ---
    public void moveHorizontal(int distance) {
        erase();
        xPosition += distance; // antes era xPosition = distance;
        draw();
    }

    public void moveVertical(int distance) {
        erase();
        yPosition += distance; // antes era yPosition = distance;
        draw();
    }

    // --- MOVIMIENTO SUAVE ---
    public void slowMoveHorizontal(int distance) {
        int delta = (distance < 0) ? -1 : 1;
        int steps = Math.abs(distance);

        for (int i = 0; i < steps; i++) {
            xPosition += delta;
            draw();
        }
    }

    public void slowMoveVertical(int distance) {
        int delta = (distance < 0) ? -1 : 1;
        int steps = Math.abs(distance);

        for (int i = 0; i < steps; i++) {
            yPosition += delta;
            draw();
        }
    }

    // --- CAMBIO DE TAMAÑO Y COLOR ---
    public void changeSize(int newHeight, int newWidth) {
        erase();
        height = newHeight;
        width = newWidth;
        draw();
    }

    public void changeColor(String newColor) {
        color = newColor;
        draw();
    }

    // --- DIBUJAR Y BORRAR ---
    private void draw() {
        if (isVisible) {
            Canvas canvas = Canvas.getCanvas();
            canvas.draw(this, color, new java.awt.Rectangle(xPosition, yPosition, width, height));
            canvas.wait(10);
        }
    }

    private void erase() {
        if (isVisible) {
            Canvas canvas = Canvas.getCanvas();
            canvas.erase(this);
        }
    }
}




