package silkroad;
import java.util.Random;

/**
 * Tienda que escoge la posición en la que quiere ubicarse, no la que le indican
 * @author (Sara Gonzalez)
 */

public class AutonomousStore extends Store {
    public AutonomousStore(int roadLength) {
        super(new Random().nextInt(Math.max(1, roadLength)),
              10 + new Random().nextInt(91)); // 10..100
    }
}
