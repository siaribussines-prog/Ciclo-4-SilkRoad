package silkroad;


/**
 * Write a description of class FighterRobot here.
 * 
 * @author (Sara Gonzalez)
 */
public class FighterRobot extends Robot {
    public FighterRobot(int x, int y) { super(x, y); }
}
