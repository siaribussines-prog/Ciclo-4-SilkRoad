package silkroad;
/**
 * los únicos robots que pueden tomar su dinero son los que tienen más dinero que
ellas
 * @author (Sara Gonzalez)
 */

public class FighterStore extends Store {
    public FighterStore(int location, int tenges) { super(location, tenges); }

    @Override
    public int collect(Robot r) {
        return (r instanceof FighterRobot) ? super.collect() : 0;
    }
}

