package silkroad;
/**
 * los únicos robots que pueden tomar su dinero son los que tienen más dinero que
 ellas
 * @author (Sara Gonzalez)
 */
public class FighterStore extends Store {

    public FighterStore(int location, int tenges) {
        super(location, tenges);
    }

    @Override
    public int collect(Robot r) {
        if (r == null) return 0;
        // Solo entrega si el robot tiene más dinero que la tienda
        if (r.getMoney() > getTenges()) {
            // respeta también la regla del robot (tender toma mitad, etc.)
            return super.collect(r);
        }
        return 0;
    }
}

