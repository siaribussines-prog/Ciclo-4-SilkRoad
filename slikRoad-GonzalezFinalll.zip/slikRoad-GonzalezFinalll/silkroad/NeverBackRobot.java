package silkroad;

/**
 * Robot que (nunca se devuelve
 * 
 * @author (Sara Gonzalez)
 */
public class NeverBackRobot extends Robot {
    public NeverBackRobot(int x, int y) { super(x, y); }

    @Override
    public boolean allowMove(int meters) {
        return meters >= 0;  // prohíbe movimientos negativos
    }
}
