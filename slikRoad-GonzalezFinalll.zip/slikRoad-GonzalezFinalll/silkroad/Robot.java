package silkroad;
import shapes.*;
import java.util.List;
import java.util.ArrayList;
/**
 * La clase contiene los metodos de robot de SkillRoad
 * Sara G
 */
public class Robot {
    private int initialLocation;
    private int currentLocation;
    private Circle head;
    private Rectangle neck;
    private Rectangle body;
    private Rectangle lefthand;
    private Rectangle righthand;
    private Rectangle leftleg;
    private Rectangle rightleg;
    //ciclo 2//
    private List<Integer> profitsPerMove;  // ganancias en cada movimiento
    
    public Robot(int x, int y) {
        this.initialLocation = x;
        this.currentLocation = x;
        this.profitsPerMove = new ArrayList<>();
    
        // Cabeza
        head = new Circle();
        head.changeSize(40);
        head.setXPosition(x + 20);
        head.setYPosition(y);
    
        // Cuello
        neck = new Rectangle();
        neck.changeSize(10, 15);
        neck.setXPosition(x + 33);
        neck.setYPosition(y + 40);
    
        // Cuerpo
        body = new Rectangle();
        body.changeSize(50, 60);
        body.setXPosition(x + 10);
        body.setYPosition(y + 60);
    
        // Brazos
        lefthand = new Rectangle();
        lefthand.changeSize(10, 40);
        lefthand.setXPosition(x);
        lefthand.setYPosition(y + 60);
    
        righthand = new Rectangle();
        righthand.changeSize(10, 40);
        righthand.setXPosition(x + 60);
        righthand.setYPosition(y + 60);
    
        // Piernas
        leftleg = new Rectangle();
        leftleg.changeSize(10, 25);
        leftleg.setXPosition(x + 20);
        leftleg.setYPosition(y + 115);
    
        rightleg = new Rectangle();
        rightleg.changeSize(10, 25);
        rightleg.setXPosition(x + 40);
        rightleg.setYPosition(y + 115);
    
        // Mostrar todo
        head.makeVisible();
        neck.makeVisible();
        body.makeVisible();
        lefthand.makeVisible();
        righthand.makeVisible();
        leftleg.makeVisible();
        rightleg.makeVisible();
    }


    
    public void changeColor(String color){
    head.changeColor(color);
    neck.changeColor(color);
    body.changeColor(color);
    lefthand.changeColor(color);
    righthand.changeColor(color);
    leftleg.changeColor(color);
    rightleg.changeColor(color);
    }
    
    public void graphicMove(int row, int col){
        int baseX = 250 * col;
        int baseY = 250 * row;
    
        head.setXPosition(98 + baseX);
        head.setYPosition(90 + baseY);
        neck.setXPosition(118 + baseX);
        neck.setYPosition(140 + baseY);
        body.setXPosition(95 + baseX);
        body.setYPosition(147 + baseY);
        lefthand.setXPosition(85 + baseX);
        lefthand.setYPosition(155 + baseY);
        righthand.setXPosition(155 + baseX);
        righthand.setYPosition(155 + baseY);
        leftleg.setXPosition(130 + baseX);
        leftleg.setYPosition(180 + baseY);
        rightleg.setXPosition(110 + baseX);
        rightleg.setYPosition(180 + baseY);
    }

    
    public void makeVisible() {
        head.makeVisible();
        neck.makeVisible();
        body.makeVisible();
        lefthand.makeVisible();
        righthand.makeVisible();
        leftleg.makeVisible();
        rightleg.makeVisible();
    }
    
    public void makeInvisible() {
        head.makeInvisible();
        neck.makeInvisible();
        body.makeInvisible();
        lefthand.makeInvisible();
        righthand.makeInvisible();
        leftleg.makeInvisible();
        rightleg.makeInvisible();
    }
    public int getLocation() { 
        return currentLocation; 
    }
    
    public int getInitialLocation() { 
        return initialLocation; 
    }

    public void reset() {
        this.currentLocation = initialLocation;
    }

    public void move(int meters) {
        currentLocation += meters;
    }
    
    //Ciclo 2// aca se registran las ganancias

    public void addProfit(int profit) {
        profitsPerMove.add(profit);
    }

    public List<Integer> getProfitsPerMove() {
        return profitsPerMove;
    }
    
    /**
     * Devuelve el dinero total acumulado por el robot.
     * Suma las ganancias registradas en profitsPerMove.
     * Si el total es negativo, devuelve 0 para no afectar
     */
    public int getMoney() {
        int sum = 0;
        for (Integer p : profitsPerMove) {
            sum += p;
        }
        return Math.max(0, sum);
    }
    // ciclo 4
     /** movimiento (por defecto se permite todo) */
    public boolean allowMove(int meters) { 
        return true; 
    }

    /** cuánto dinero recoge (por defecto toma todo). */
    public int adjustCollection(int amount) { 
        return amount; 
    }
}














