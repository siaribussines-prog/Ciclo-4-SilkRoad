package silkroad;
/**
 * Clase de excepciones de SilkRoad.
 * Permite manejar mensajes de error.
 *
 * @author Sara Sofia Gonzalez
 */
public class SilkRoadException extends Exception {
    public static final String LONGITUD_INVALIDA = "Error: la longitud de la ruta debe ser mayor a 0.";
    public static final String UBICACION_INVALIDA_TIENDA = "Error: ubicación innvalida para la tienda.";
    public static final String TIENDA_DUPLICADA = "Error: ya existe una tienda en esa ubicación.";
    public static final String ROBOT_DUPLICADO = "Error: ya existe un robot en esa ubicación inicial.";
    public static final String TIENDA_NO_ENCONTRADA = "Error: no se encontró la tienda en esa ubicación.";
    public static final String ROBOT_NO_ENCONTRADO = "Error: no se encontró el robot en esa ubicación.";
    public static final String MOVIMIENTO_INVALIDO = "Error: el movimiento del robot hace que se salga de la ruta.";
    public static final String TENGES_INVALIDOS = "El número de tenges debe ser mayor o igual a 0.";
    public static final String UBICACION_INVALIDA_ROBOT = "Ubicación inválida para el robot.";
    public static final String SMART_ROBOT = "SmartRobot decidió no moverse porque no hay ganancia esperada.";

    public SilkRoadException(String message) {
        super(message);
    }
}
