package silkroad;
/**
 * Este robot mira la ganancia antes de moverse, se mueve solo si hay ganancia positiva osea (tenges – distancia > 0)
 * 
 * @author (Sara Gonzalez) 
 */

public class SmartRobot extends Robot {

    public SmartRobot(int x, int y) {
        super(x, y);
    }

    @Override
    public boolean allowMove(int meters) {
        // Siempre permite el movimiento
        return true;
    }

    @Override
    public void move(int meters) {
        // aquí solo hace el desplazamiento normal.
        super.move(meters);
    }

    @Override
    public int adjustCollection(int amount) {
        // No recibe dinero adicional comportamiento estándar
        return amount;
    }
}
