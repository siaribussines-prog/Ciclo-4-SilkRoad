package silkroad;
import shapes.*;
/**
 * La clase que tiene los metodos de SkillRoad en Store
 * Sara G 
 */
public class Store {
    private int location;
    private int tenges;
    private int initialTenges;
    private Rectangle box;
    private Triangle rooft;
    //ciclo 2//
    private int emptiedCount;

    public Store(int location, int tenges) {
        this.location = location;
        this.tenges = tenges;
        this.initialTenges = tenges;
        box = new Rectangle();
        box.changeSize(30, 100);
        box.moveHorizontal(75);
        box.moveVertical(50);
        rooft = new Triangle();
        rooft.changeSize(50, 100);
        rooft.moveHorizontal(125);
        rooft.moveVertical(0);
    }

    public void changeColor(String color){
        box.changeColor(color);
        rooft.changeColor(color);
    }

    public void graphicMove(int row, int col){
        box.moveHorizontal(75+250*col);
        box.moveVertical(50+250*row);
        rooft.moveHorizontal(125+250*col);
        rooft.moveVertical(250*row);
    }

    public void makeVisible() {
        box.makeVisible();
        rooft.makeVisible();
    }

    public void makeInvisible() {
        box.makeInvisible();
        rooft.makeInvisible();
    }

    public int getLocation() { return location; }
    public int getTenges()   { return tenges;   }

    public void reset() {
        this.tenges = initialTenges;
    }

    /** Comportamiento por defecto: vacía la tienda y retorna todo el dinero. */
    public int collect() {
        int temp = tenges;
        tenges = 0;
        if (temp > 0) {
            emptiedCount++; // cada vez que se vacía, incrementa
        }
        return temp;
    }

    /** Punto de extensión (Ciclo 4): por defecto delega al collect() normal. */
    public int collect(Robot r) {
        return collect();
    }

    //ciclo 2//
    public int getEmptiedCount() { 
        return emptiedCount; 
    }
}

















