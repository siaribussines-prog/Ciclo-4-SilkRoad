package silkroad;
import shapes.*;
/**
 * La clase que tiene los metodos de SkillRoad en Store
 * Sara G 
 */
public class Store {
    private int location;
    private int tenges;
    private int initialTenges;
    private Rectangle box;
    private Triangle rooft;
    // ciclo 2
    private int emptiedCount;

    // --- Layout (ajústalos si quieres otra proporción) ---
    private static final int CELL   = 250;  // tamaño de celda del Board
    private static final int BOX_W  = 110;  // ancho caja
    private static final int BOX_H  = 70;   // alto  caja
    private static final int ROOF_W = 120;  // base del techo (triángulo)
    private static final int ROOF_H = 60;   // alto  del techo

    public Store(int location, int tenges) {
        this.location = location;
        this.tenges   = tenges;
        this.initialTenges = tenges;

        // Crear figuras con tamaños definitivos (sin moverlas todavía)
        box = new Rectangle();
        box.changeSize(BOX_H, BOX_W);

        rooft = new Triangle();
        rooft.changeSize(ROOF_H, ROOF_W);
    }

    public void changeColor(String color){
        box.changeColor(color);
        rooft.changeColor(color);
    }

    /** Centra la tienda en la celda (row,col) y alinea el techo encima de la caja. */
    public void graphicMove(int row, int col){
        int cellX = col * CELL;
        int cellY = row * CELL;

        // Centro de la celda
        int centerX = cellX + CELL / 2;
        int centerY = cellY + CELL / 2;

        // Caja: Rectangle usa esquina superior izquierda como referencia
        int boxLeft = centerX - BOX_W / 2;
        int boxTop  = centerY - BOX_H / 2 + 10; // +10 baja un poco la caja

        box.setXPosition(boxLeft);
        box.setYPosition(boxTop);

        // Techo: Triangle usa el VÉRTICE SUPERIOR como referencia
        int roofTopX = centerX;               // centrado horizontalmente
        int roofTopY = boxTop - ROOF_H + 2;   // justo encima (+2 solapa leve)

        rooft.setXPosition(roofTopX);
        rooft.setYPosition(roofTopY);
    }

    public void makeVisible() {
        box.makeVisible();
        rooft.makeVisible();
    }

    public void makeInvisible() {
        box.makeInvisible();
        rooft.makeInvisible();
    }

    public int getLocation() { return location; }
    public int getTenges()   { return tenges;   }

    public void reset() {
        this.tenges = initialTenges;
    }

    /** Vaciado completo (compatibilidad). */
    public int collect() {
        int temp = tenges;
        tenges = 0;
        if (temp > 0) {
            emptiedCount++;
        }
        return temp;
    }

    /** Punto de extensión (ciclo 4): por defecto delega al collect() normal. */
    public int collect(Robot r) {
        int amount = collect();      // vacía la tienda y devuelve lo que tení
        return r.adjustCollection(amount); // el robot decide si toma todo la mitad, etc.
    }

    // ciclo 2
    public int getEmptiedCount() {
        return emptiedCount;
    }
}


















