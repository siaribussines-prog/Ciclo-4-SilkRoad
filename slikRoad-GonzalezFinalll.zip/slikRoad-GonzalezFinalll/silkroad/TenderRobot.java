package silkroad;

/**
 * WRobot que sólo toma la mitad de dinero de las tiendas que visita
 * 
 * @author (Sara Gonzalez)
 */
public class TenderRobot extends Robot {
    public TenderRobot(int x, int y) {
        super(x, y);
    }

    public int moveCost(int meters) {
        return Math.abs(meters) / 2; // paga la mitad
    }
}

