package silkroad;

/**
 * WRobot que sólo toma la mitad de dinero de las tiendas que visita
 * 
 * @author (Sara Gonzalez)
 */
public class TenderRobot extends Robot {
    public TenderRobot(int x, int y) {
        super(x, y);
    }

    @Override
    public int adjustCollection(int amount) {
        return amount / 2;        // solo toma la mitad
    }
}
