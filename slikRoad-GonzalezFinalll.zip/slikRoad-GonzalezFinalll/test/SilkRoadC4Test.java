package test;
import silkroad.*;
import static org.junit.Assert.*;
import org.junit.Test;
/**
 *Prueba Unitaria 
 */

public class SilkRoadC4Test {

    @Test
    public void neverBackRobotNoPermiteMovimientoNegativo() throws Exception {
        SilkRoad sr = new SilkRoad(30);
        sr.placeStore(10, 40);                    // tienda normal
        sr.placeRobot("neverback", 12);

        // intentar devolverlo y debería fallar
        sr.moveRobot(12, -3);
        assertFalse("Movimiento negativo no debería estar ok", sr.ok());
    }

    @Test
    public void tenderRobotCobraLaMitad() throws Exception {
        SilkRoad sr = new SilkRoad(30);
        sr.placeStore(10, 80);                    // a 5 metros desde 5
        sr.placeRobot("tender", 5);

        sr.moveRobot(5, +5);                      // costo = 5, recoge 80/2 = 40 ganancia = 35
        assertTrue(sr.ok());
        assertEquals(35, sr.profit());
    }

    @Test
    public void fighterStoreSoloDejaFighterRobot() throws Exception {
        SilkRoad sr = new SilkRoad(30);
        Store fs = new FighterStore(8, 60);       // si se usa FighterStore
        int[] p = sr.positionToCoords(8, 30);
        fs.graphicMove(p[0], p[1]);
        sr.placeRobot("normal", 0);
        sr.placeRobot("fighter", 1);

        sr.moveRobot(0, 8);                       // normal cae en 8 no debería cobrar
        assertTrue(sr.ok());
        int profitTrasNormal = sr.profit();

        sr.moveRobot(1, 7);                       // fighter cae en 8, cobra 60 - 7 = 53
        assertTrue(sr.ok());
        assertTrue("Fighter debe aumentar el profit",
                   sr.profit() > profitTrasNormal);
    }

    @Test
    public void smartRobotEvitaMovimientoNoRentable() throws Exception {
        SilkRoad sr = new SilkRoad(30);
        sr.placeStore(20, 3);                     // poca plata
        sr.placeRobot("smart", 10);

        sr.moveRobot(10, +10);                    // distancia 10, tenges 3 -> no rentable
        assertFalse("SmartRobot debe rechazar movimiento no rentable", sr.ok());
    }

    @Test
    public void autonomousStoreQuedaDentroDeLaRuta() throws Exception {
        // Solo si se usa AutonomousStore
        int len = 50;
        SilkRoad sr = new SilkRoad(len);
        Store as = new AutonomousStore(len);
        assertTrue(as.getLocation() >= 0 && as.getLocation() < len);
    }
}
