package test;
import silkroad.*;
import shapes.*;

/**
 * Resuelve y simula la máxima utilidad por día.
 * Cada fila del arreglo osea days representa un día con pares (venta, costo):
 */
public class SilkRoadContest {

    /** Máxima utilidad de un día */
    public int solve(int[] day) {
        int max = Integer.MIN_VALUE;
    
        for (int j = 0; j + 1 < day.length; j += 2) {
            int venta = day[j];
            int costo = day[j + 1];
            int utilidad = venta - costo;
            if (utilidad > max) {
                max = utilidad;
            }
        }
    
        // Si no se encontró ninguna utilidad lo que significa que el día fue vacío
        if (max == Integer.MIN_VALUE) {
            return 0;
        } else {
            return max;
        }
    }


    /** Máxima utilidad por día para varios días. */
    public int[] solve(int[][] days) {
        int[] maximos = new int[days.length];
        for (int i = 0; i < days.length; i++) {
            maximos[i] = solve(days[i]);
        }
        return maximos;
    }

    /** Simula imprimiendo la máxima utilidad de cada día. */
    public void simulate(int[][] days, boolean slow) {
        int[] resultados = solve(days);
        System.out.println("Simulación de la maratón:");
        for (int i = 0; i < resultados.length; i++) {
            System.out.println("Día " + (i + 1) + " → Máxima utilidad: " + resultados[i]);
            if (slow) {
                try { Thread.sleep(1000); } catch (InterruptedException ignored) {}
            }
        }
        System.out.println("✅ Simulación finalizada.");
    }
}
